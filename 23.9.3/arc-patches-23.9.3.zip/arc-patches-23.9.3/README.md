# Patches for Arc Redpill Loader

## List of all Modules
https://github.com/AuxXxilium/AuxXxilium/wiki/Arc:-Modules

### Links

- <a href="https://github.com/AuxXxilium">Overview</a>
- <a href="https://github.com/AuxXxilium/AuxXxilium/wiki">Wiki and Informations</a>
- <a href="https://github.com/AuxXxilium/arc/releases/latest">Download</a>

### Thanks
All code was based on the work of TTG, pocopico, jumkey, fbelavenuto and others involved in continuing TTG's original redpill-load project.